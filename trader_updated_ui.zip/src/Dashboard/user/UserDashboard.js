import React from 'react'

const UserDashboard = () => {
  return (
    <div>
      <h1>userDashboard</h1>
    </div>
  )
}

export default UserDashboard
