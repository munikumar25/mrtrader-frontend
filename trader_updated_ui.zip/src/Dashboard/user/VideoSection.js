import React from 'react'

const VideoSection = () => {
  return (
    <div>
      <div className='card'>
        <h2>Video</h2>
      </div>
    </div>
  )
}

export default VideoSection
