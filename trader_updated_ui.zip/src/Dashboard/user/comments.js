import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { CommentSection} from 'react-comments-section'
import 'react-comments-section/dist/index.css'

// const user = localStorage.getItem('userData');

const Comments = () => {
    const [data,setCommentData] = useState();
   
    useEffect(()=>{
        axios.get("http://localhost:8000/api/getcomment").then((response)=>{
           const json = JSON.stringify(response.data);
           const d = console.log(JSON.parse(json));
           setCommentData(JSON.parse(json));
    })
  
  },[]);


//   const data =[
    // {
    //   userId: '02b',
    //   comId: '017',
    //   fullName: 'Lily',
    //   userProfile: 'https://www.linkedin.com/in/riya-negi-8879631a9/',
    //   text: 'I think you have a point🤔',
    //   avatarUrl: 'https://ui-avatars.com/api/name=Lily&background=random',
    //   replies: []
    // }
//   ]    
    return (
      // <CommentSection
      //     currentUser={{
      //       currentUserId: '01a',
      //       currentUserImg:
      //         `https://ui-avatars.com/api/name=Muni&background=random`,
      //       currentUserFullName: 'muni'
      //     }}
      //     logIn={{
      //       loginLink: 'http://localhost:3001/',
      //       signupLink: 'http://localhost:3001/'
      //     }}
      //     commentData={data}
      //     onSubmitAction={(data) => console.log('check submit, ', data)}
      //     currentData={(data) => {
      //       console.log('curent data', data)
      //     }}
      //   />
      <>
      
      </>
  )
}

export default Comments
