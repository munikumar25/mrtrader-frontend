import React from 'react'

const Player = () => {
  return (
    <div>
      <h1>Player</h1>
    </div>
  )
}

export default Player
