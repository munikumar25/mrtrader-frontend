import React from 'react'

const Polls = () => {
  return (
    <div>
      
    </div>
  )
}

export default Polls
