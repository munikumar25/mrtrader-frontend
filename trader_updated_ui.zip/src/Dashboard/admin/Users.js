import React, { useEffect ,useState} from 'react'
import axios from 'axios';
import DataTable from 'react-data-table-component';
import '../../Assert/css/DataTables.css';
import { useForm } from "react-hook-form";

const useStyles = makeStyles({
  root: {
    width: "100%"
  },
  button: {
    marginRight: 10,
    borderRadius: 100,
    fontSize: 20,
  },
  instructions: {
    marginTop: 2,
    marginBottom: 5
  }
});

const Users = () => { 
  const classes = useStyles();
  const [loading, setLoading] = useState(false);
  const [user,setUser] = useState([]);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [registerUser,setRegisterUser] = useState({
    userId:"",
    firstName : "",
    lastName : "",
    email : "",
    password:"",
    gender:"",
    confirmPassword:"",
    mobileNo : "",
    uniqueId : "",
    selectTrade:"",
    role:1
});
const {firstName,lastName,email,mobileNo,password,confirmPassword,uniqueId,selectTrade,gender,role} = registerUser;
const onChangeData = (e) =>{
  setRegisterUser({...registerUser,[e.target.name]:e.target.value});
}
const { register, handleSubmit, formState: { errors } } = useForm();
useEffect(()=>{ 
    setLoading(true); 
    axios.get("http://localhost:8000/api/user/data").then(res=>JSON.stringify(res.data)).then((json)=>{
     const data = JSON.parse(json);
     setUser(data);
    })
    setLoading(false);
  },[]);
  function editUserData(id) {
    axios.get(`http://localhost:8000/api/user/data/${id}`).then(userData=>JSON.stringify(userData.data)).then(json=>{
      const data = JSON.parse(json);
    
        registerUser.userId = data.user_id;
        registerUser.firstName = data.first_name;
        registerUser.lastName = data.last_name;
        registerUser.email = data.email;
        registerUser.gender= data.gender;
        registerUser.mobileNo = data.mobile_no;
        registerUser.uniqueId = data.unique_code;
        registerUser.selectTrade= data.trade_account;
        registerUser.role= data.role;
    })
  }
  const column = [
    {
      name:"S.no",
      selector:row=>row.id,
      sortable:true
    },
    {
      name:"First Name",
      selector:row=>row.first_name
    },
    { 
      name:"Email",
      selector:row=>row.email
    },
    {
      name:"Mobile No",
      selector:row=>row.mobile_no
    },
    {
      name:"Status",
      selector:row=>row.user_status,
      
    },
    {
      name:"Action",
      selector:function ({user_id}) {
        return <>
        <i class="bi bi-pencil-square" onClick={e => editUserData(user_id)} style={{fontSize:"20px",color:"blue",margin:"8px"}} data-bs-toggle="modal" data-bs-target="#myEdit"></i>
        <i class="bi bi-eye" style={{fontSize:"20px",color:"green",margin:"8px"}} data-bs-toggle="modal" data-bs-target="#myView"></i>
        <i class="bi bi-trash" style={{fontSize:"20px",color:"red",margin:"8px"}}></i>
        {/* <button onclick="clickDeactivateUser(this)" class="btn btn-success btn-sm" style={{marginRight:"15px"}}>View</button>
        <button onclick="clickDeactivateUser(this)" class="btn btn-success btn-sm" style={{marginRight:"15px"}}>Edit</button>
        <button onclick="clickDeactivateUser(this)" class="btn btn-danger btn-sm">Delete</button> */}

        </>;
    }
    }
  ];
  
  const customStyles = {
    rows: {
      style: {
        minHeight: '50px', // override the row height
      }
    },
    headCells: {
      style: {
        paddingLeft: '8px', // override the cell padding for head cells
        paddingRight: '8px',
      },
    },
     
    cells: {
      style: {
        paddingLeft: '8px', // override the cell padding for data cells
        paddingRight: '8px',
      },
    },
  };
  
  function handleFIlter(event){
    console.log("event.target.value.toLowerCase()");
      const newData = user.filter(row=>{
        return row.first_name.toLowerCase().includes(event.target.value.toLowerCase())
      })
      setUser(newData)
  }
  const onChangeDataGender = (e) =>{
    setRegisterUser({...registerUser,gender:e.target.value});
}
const onChangeSelectedData = (e) =>{
    setRegisterUser({...registerUser,selectTrade:e.target.value});
}

const submittedData = (e) =>{
    e.preventDefault();
    axios.post("http://localhost:8000/api/user/saveUser",registerUser).catch((error)=>{
        if (error.response) {
            console.log(error.response.data);
            console.log(error.response.status);
            console.log(error.response.headers);
          } else if (error.request) {
            console.log(error.request);
          } else {
            console.log('Error', error.message);
          }
    });
    // .then(res=>{
    //     JSON.stringify(res).then(json=>{
    //         const s = JSON.parse(json);
    //         console.log("das"+s.success)
    //         if(s.success === true) {
    //             redirect('/Login');
    //         }
    //     })
        
    // });
    console.log(registerUser)
}
  return (
    <>
        <div id="content-wrapper" className="d-flex flex-column" style={{marginTop:"60px"}}>
        <div id="content">
          <div className="container-fluid" style={{marginTop:"-50px",top:"15px",position:'sticky'}}>
            <div className="card shadow mb-4 h-50" >
              <div className="card-header py-3">
                <span className="m-0 font-weight-bold text-primary" style={{fontSize:"20px",textAlign:"center"}}>Users List</span>
                <input type='text' onChange={handleFIlter} style={{float:"right"}} placeholder='Search'/>
              </div>
              <div className="card-body">
                <div className="table-responsive">
                <DataTable
                  progressPending={loading}
                  columns={column}
                  data={user}
                  pagination
                  fixedHeader
                  fixedFooter
                  customStyles={customStyles}
                  paginationPerPage={rowsPerPage}
                  paginationRowsPerPageOptions={[5,10,50,100]}
                ></DataTable>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
  <div className="modal" id="myEdit" style={{marginTop:"60px",color:"black"}}>
  <div className="modal-dialog">
    <div className="modal-content">
      <div className="modal-header">
        <h4 className="modal-title">User Edit</h4>
        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div className="modal-body">
        <form onSubmit={submittedData}>
          <div className="row register-form">
            <div className="col-md-6">
              <div className="form-group">
                <lable >First Name <span className='star'>*</span></lable>
                <input type="text" className="form-control" placeholder="First Name" name="firstName" value = {firstName} onChange={onChangeData} required/>
              </div>
              <div className="form-group">
                <lable >Last Name <span className='star'>*</span></lable>
                <input type="text" className="form-control" placeholder="Last Name" name="lastName" value = {lastName} onChange={onChangeData} required/>
              </div>
              <div className="form-group">
                <lable >Gender <span className='star'>*</span></lable>
                <select className="form-control" name={gender} onChange={onChangeDataGender}>
                  <option className="hidden"  selected disabled>-- Select Gender --</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Trans">Trans</option>
                </select>
              </div>
              <div className="form-group">
                <lable >Email <span className='star'>*</span></lable>
                <input type="email" className="form-control" placeholder="mrtr****@gmail.com" name="email" value={email} onChange={onChangeData} required/>
              </div>
              <div className="form-group">
                <lable >Enter Your Phone no <span className='star'>*</span></lable>
                <input type="number" className="form-control" placeholder="+91 80000 80000" name="mobileNo" value={mobileNo} onChange={onChangeData} required/>
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <lable >Aadhar No <span className='star'>*</span></lable>
                <input type="number" className="form-control" placeholder="Aadhar No" name="password" value={password} onChange={onChangeData} required/>
              </div>
              <div className="form-group">
                <lable >Pan No <span className='star'>*</span></lable>
                <input type="text" className="form-control"  placeholder="Pan no" name="confirmPassword" value={confirmPassword} onChange={onChangeData} required/>
              </div>
              {errors.mobile && <p>Please Enter Valid Mobile Number</p>}
              <div className="form-group">
                <lable >Select Trade Account <span className='star'>*</span></lable>
                <select className="form-control" name={selectTrade} onChange={onChangeSelectedData}>
                  <option className="hidden"  selected disabled>-- Select --</option>
                  <option value="Zerodha">Zerodha</option>
                  <option value="TradeX">TradeX</option>
                  <option value="TradeY">TradeY</option>
                </select>
              </div>
              <div className="form-group">
                <lable >Enter Trade Id <span className='star'>*</span></lable>
                <input type="text" className="form-control" placeholder="Enter Unique Id" name="uniqueId"  value={uniqueId} onChange={onChangeData} required/>
              </div>
            </div>  
          </div>
          <input style={{float:"center"}} type="submit" className="btnRegister"  value="Update User Data"/>
          <br />
          <br />
          {/* <div style={{float:"center"}}><h6 style={{color:"black"}}>Your Existing User?<a href='/Login'>Please Login </a> </h6></div> */}
        </form>
        </div>
      </div>
    </div>
  </div>

<div className="modal" id="myView" style={{marginTop:"60px",color:"black"}}>
  <div className="modal-dialog">
    <div className="modal-content">
      <div className="modal-header">
        <h4 className="modal-title">User Data View</h4>
        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div className="modal-body">
        Modal body..
      </div>
    </div>
  </div>
</div>
    </>
  )
}

export default Users
