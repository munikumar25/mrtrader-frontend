import React from 'react'

const Comments = () => {
  return (
    <div>
      <h1>Admin Comments</h1>
    </div>
  )
}

export default Comments
