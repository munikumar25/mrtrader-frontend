import React from 'react'

const UserNotAccess = () => {
  return (
    <div>
      <canter>User NOt Access this page</canter>
    </div>
  )
}

export default UserNotAccess
