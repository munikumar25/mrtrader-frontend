import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      <center>Page Not Found</center>
    </div>
  )
}

export default PageNotFound
