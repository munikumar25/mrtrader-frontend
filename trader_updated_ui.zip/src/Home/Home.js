import React from 'react';
// import HeaderNav from './HeaderNav';
import HeaderSection from './HeaderSection';
import Body from './Body/Body';
const Home = () => {
  return (
    <div>
      {/* <HeaderNav /> */}
      <HeaderSection />
      <Body />
    </div>
  )
}

export default Home
