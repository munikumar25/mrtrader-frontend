import React from 'react'
import banner from '../Assert/images/banner.png';
const HeaderSection = () => {
  return (
    <div>
      <img src={banner} alt="Banner" height="548vh" width={1365} />
    </div>
  )
}

export default HeaderSection
